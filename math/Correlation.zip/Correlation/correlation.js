/*
correlation.js

Perform signal correlation on control-rate data.

This makes use of the convolution property which 
says the the Fourier Transform converts convolution
into multiplication. So, the signals are windowed, 
transformed, multiplied, and inverse-transformed.

Made by Michael Krzyzaniak at the Synthesis Center
Under the direction of Sha Xin Wei, at Arizona State
University's School of Arts, Media and Engineering 
in Fall of 2014.

mkrzyzan@asu.edu

Based on an ANSI C Radix 2 Decimitaion in Time
Short Term Fourier Transform implementation
also by Michael Krzyzaniak. Some remenants of that 
implementation still exist in this file for future 
development.
*/

inlets  = 2;
outlets = 1;

var REAL_INLET_1 = 0;
var REAL_INLET_2 = 1;
//var IMAG_INLET = 1;

var MAGNITUDE_OUTLET   = 0;
//var DEBUG_OUTLET   = 1;
//var DEBUG_OUTLET2   = 2;
//var PHASE_OUTLET = 1;

setinletassist(REAL_INLET_1, "real values or a list of values");
setinletassist(REAL_INLET_2, "imaginary values or a list of values");

setoutletassist(MAGNITUDE_OUTLET  , "fft magnitudes");
//setoutletassist(PHASE_OUTLET, "fft phases");
//setoutletassist(FREQ_OUTLET, "estimation of fundamental");

var fft_size = 64;

if(jsarguments.length > 1)
  fft_size = jsarguments[1];

//public functions way at the bottom of this file...

Math.TWO_PI = 2 * Math.PI;
Math.hypot =  function(x, y){return Math.sqrt((x*x)+(y*y))};

/*OpaqueFFTStruct-----------------------------------------------*/
function STFT(numSamples)
{
  this.numSamples = numSamples; //may be arbitrary
  this.N                     = smallestPowerOfTwoGreaterThanOrEqualTo(numSamples)
  this.overlap               = this.N;//1/4 * numSamples; 
  this.real                  = []; this.real.length = this.N;
  this.imag                  = []; this.imag.length = this.N;
  this.analysisWindowBuffer  = []; this.analysisWindowBuffer.length  = this.N;
  this.synthesisWindowBuffer = []; this.synthesisWindowBuffer.length = this.N;

  this.analysisWindowFunction  = null;
  this.synthesisWindowFunction = null;

  this.setOverlap (7.0/8.0);
  //this.setOverlap (0);
  this.setWindowFunct (fftHammingWindow, true );
  this.setWindowFunct (fftHammingWindow, false);
};


/*-----------------------------------------------------------------------*/
STFT.prototype.transform = function(realIn, imagIn, numInSamples, inverse, polarOutput)
{
  var i;
  var result = {real: [], imag: []};

  this.real = realIn.slice(0, this.numSamples);
  this.imag = imagIn.slice(0, this.numSamples);

  if(!this.inverse)
    this.applyWindow(true);

  this.bitReverseIndices();

  this.radix2DIT(inverse);

  if(polarOutput)
    this.rectangularToPolar();
  
  //if(!this.inverse)
    //this.scaleMagnitudes(0, 1);

  result.real = this.real.slice(0, this.numSamples);
  result.imag = this.imag.slice(0, this.numSamples);
  return result;
}

/*-----------------------------------------------------------------------*/
STFT.prototype.setWindowFunct = function(windowFunct, /*BOOL*/ analysis)
{
  var i;
  var buffer = (analysis) ? this.analysisWindowBuffer : this.synthesisWindowBuffer;
  if (analysis) 
    this.analysisWindowFunct = windowFunct; 
  else 
    this.synthesisWindowFunct = windowFunct;
    
  if(windowFunct != null)
    {
      windowFunct(buffer, this.numSamples);
      for(i=this.numSamples; i<this.N*0.5; i++)
        buffer[i] = 0;
    }
}

/*-----------------------------------------------------------------------*/
/*
fftWindowFunct_t fftWindowFunction(FFT* self, BOOL analysis)
{
  return (analysis) ? this.analysisWindowFunct : this.synthesisWindowFunct;
}
*/

/*-----------------------------------------------------------------------*/
STFT.prototype.radix2DIT = function(isInverse)
{
  var twoPiOverN = Math.TWO_PI / this.N;
  var omegaTwoPiOverN;
  var subTransform, butterfly;
  
  var numSubTransforms = this.N, numButterflies = 1, omega;
  var wr, wi, r=this.real, i=this.imag, tempr, tempi;

  var arrayOffset = 0;
  
  while((numSubTransforms >>= 1) > 0)
    {
	  arrayOffset = 0;
      //r = real, i = imag;
      for(subTransform=0; subTransform<numSubTransforms; subTransform++)
        {
          omega = 0;
          for(butterfly=0; butterfly<numButterflies; butterfly++)
            {
              omegaTwoPiOverN = omega * twoPiOverN;
              tempr   =  Math.cos(omegaTwoPiOverN);
              tempi   = -Math.sin(omegaTwoPiOverN);
              if(isInverse)
                tempi = -tempi;
              wr = (r[numButterflies + arrayOffset] * tempr) - (i[numButterflies + arrayOffset] * tempi);
              wi = (r[numButterflies + arrayOffset] * tempi) + (i[numButterflies + arrayOffset] * tempr);
              tempr = r[arrayOffset]; tempi = i[arrayOffset];
              r[arrayOffset] += wr;
              i[arrayOffset] += wi;
              r[numButterflies + arrayOffset] = tempr - wr;
              i[numButterflies + arrayOffset] = tempi - wi;
              omega += numSubTransforms;
              //r++, i++;
              arrayOffset++;
            }
            //r += numButterflies, i += numButterflies;
            arrayOffset += numButterflies;
        }
      numButterflies <<= 1;
    }
 
    if(isInverse)
      {
        for(omega=0; omega<this.N; omega++)//just reuse some damn variable
          {
            this.real[omega] /= this.N;
            this.imag[omega] /= this.N;
          }
      }
}

/*-----------------------------------------------------------------------*/
STFT.prototype.bitReverseIndices = function()
{
  var NMinus1 = this.N-1;
  var highestBit = this.N >> 1;
  var n, nextBit, nReversed=0;
  var temp;
  
  for(n=1; n<this.N; n++)
    {
      nextBit = highestBit;
      while((nextBit + nReversed) > NMinus1) nextBit >>= 1;  //find highest unpopulated bit
      nReversed &= nextBit - 1;                              //clear all higher bits
      nReversed |= nextBit;                                  //set new bit
      
      if(nReversed > n)
        {
          temp                 = this.real[n]        ;
          this.real[n]         = this.real[nReversed];
          this.real[nReversed] = temp                ;
          temp                 = this.imag[n]        ;
          this.imag[n]         = this.imag[nReversed];
          this.imag[nReversed] = temp                ;          
        }
    }
}

/*-----------------------------------------------------------------------*/
STFT.prototype.rectangularToPolar = function()
{
  var i;
  var temp;
  
  for(i=0; i<this.N; i++)
    {
      temp = this.real[i];
      this.real[i] = Math.hypot(this.real[i], this.imag[i]);
      this.imag[i] = Math.atan2(this.imag[i], temp);
    }
}

/*-----------------------------------------------------------------------*/
STFT.prototype.scaleMagnitudes = function(min, max)
{
  var minSample = new Number(1000000);
  var maxSample = 0;
  var i;
  
  for(i=0; i<this.N; i++)
    {
      if(this.real[i] < minSample)
        minSample = this.real[i];
      if(this.real[i] > maxSample)
        maxSample = this.real[i];
    }
    
  for(i=0; i<this.N; i++)
    this.real[i] = scalef(this.real[i], minSample, maxSample, min, max);
}

/*-----------------------------------------------------------------------*/
STFT.prototype.setOverlap = function(overlap)
{
  var temp = this.numSamples * overlap;
  temp = this.numSamples - temp;
  temp = CONSTRAIN(temp, 1, this.numSamples);
  this.overlap = temp;
}

/*-----------------------------------------------------------------------*/

STFT.prototype.getOverlap = function()
{
  return (this.N - this.overlap) / this.numSamples;
}


/*-----------------------------------------------------------------------*/
STFT.prototype.applyWindow = function(/*BOOL*/analysis)
{
  var funct = (analysis) ? this.analysisWindowFunct : this.synthesisWindowFunct;
  if(funct != null)
    {
      var i;
      var windowBuffer = (analysis) ? this.analysisWindowBuffer : this.synthesisWindowBuffer;
  
      for(i=0; i<this.N; i++)
        {
          this.real[i] *= windowBuffer[i];
          this.imag[i] *= windowBuffer[i];
        }
    }
}

/*-----------------------------------------------------------------------*/
/*
function fftRectWindow(windowBuffer, bufferSize)
{
  var i;
  for(i=0; i<bufferSize; i++)
    windowBuffer[i] = 1;
}
*/

var fftRectWindow = null;

/*-----------------------------------------------------------------------*/
function fftHannWindow(windowBuffer, bufferSize)
{
  var i;
  var phase = 0;
  var phaseIncrement = Math.TWO_PI / bufferSize;
  for(i=0; i<bufferSize; i++)
    {
      windowBuffer[i] = 0.5 * (1-Math.cos(phase));
      phase += phaseIncrement;
    }  
}

/*-----------------------------------------------------------------------*/
function fftHammingWindow(windowBuffer, bufferSize)
{
  var i;
  var phase = 0;
  var phaseIncrement = Math.TWO_PI / bufferSize;
  for(i=0; i<bufferSize; i++)
    {
      windowBuffer[i] = 0.54 - (0.46 * Math.cos(phase));
      phase += phaseIncrement;
    }  
}

/*-----------------------------------------------------------------------*/
function fftBlackmanWindow(windowBuffer, bufferSize)
{
  var i;
  var phase = 0;
  var phaseIncrement = Math.TWO_PI / bufferSize;
  var a = 0;
  var a0 = (1-a)/2.0;
  var a1 = 1/2.0;
  var a2 = a/2.0;
  
  for(i=0; i<bufferSize; i++)
    {
      windowBuffer[i] = a0 - (a1 * Math.cos(phase)) + (a2 * Math.cos(2*phase));
      phase += phaseIncrement;
    }  
}

/*-----------------------------------------------------------------------*/
function smallestPowerOfTwoGreaterThanOrEqualTo(n)
{
  var result = 1;
  while(result < n)
    result <<= 1;
  return result;
}

/*-----------------------------------------------------------------------*/
function scalef(x, in_min, in_max, out_min, out_max)
{
  return (((x - in_min) * (out_max - out_min)) / (in_max - in_min)) + out_min;
}

/*-----------------------------------------------------------------------*/
function CONSTRAIN(val, min, max)
{
  if(val < min) val = min;
  if(val > max) val = max;
  return val;
}

/*-----------------------------------------------------------------------*/
//assumes polar coords;
STFT.prototype.findFundamental = function()
{
  var highest     =-1, secondHighest     =-1;
  var highestIndex= 0, secondHighestIndex= 0;
  var i;

  //don't consider the DC component a frequency
  for(i=1; i<(this.numSamples/2.0); i++)
    {
      if(this.real[i] > highest)
        {
	      secondHighest = highest;
	      highest = this.real[i];
	      secondHighestIndex = highestIndex;
	      highestIndex = i;
        }
      else if(this.real[i] > secondHighest)
        {
	      secondHighest = this.real[i];
	      secondHighestIndex = i;
        }
    }
  return vertexOfParabolaPassingThroughPoints(highestIndex, highest, secondHighestIndex, secondHighest);
}

/*-----------------------------------------------------------------------*/
function vertexOfParabolaPassingThroughPoints(x1, y1, x2, y2)
{
  if(y1 == 0) return 0;  

  //should be y1 / y2 but this inverts points to find correct frequency  
  v =  Math.sqrt(y2) / Math.sqrt(y1);

  return (x1 + (v*x2)) / (1 + v);
}

/*-----------------------------------------------------------------------*/
fft_size *= 2; //do linear rather than circular convolution
var real_index1=0; real_index2=0;
var fft_real1 = [];
var fft_real2 = [];
var fft_imag1 = [];
var fft_imag2 = [];
var stft1 = new STFT(fft_size);
var stft2 = new STFT(fft_size);
var inverse_stft = new STFT(fft_size);

for(var i=0; i<fft_size; i++)
  fft_real1[i] = fft_real2[i] = fft_imag1[i] = fft_imag2[i] = 0;


/*-------------------------------------------*/
function list()
{
  var a = arrayfromargs(arguments);
  while(a.length)
    msg_float(a.shift());
}

/*-------------------------------------------*/
function msg_int(n)
{
  msg_float();
}

/*-------------------------------------------*/
function msg_float(n)
{
  switch(inlet)
    {
      case REAL_INLET_1:
        //fft_real[real_index] = n;
        
        fft_real1.shift();
        fft_real1.push(0);
        fft_real1[(fft_size * 0.5) - 1] = n;
        real_index1++; real_index1 %= fft_size * 0.5 * (1 - stft1.getOverlap());
        /*
        fft_real1.shift();
        fft_real1.push(n);        
        real_index1++; real_index1 %= fft_size * (1 - stft1.getOverlap());
        */
        if(real_index1 == 0)
          {
            var result = correlate();
            outlet(MAGNITUDE_OUTLET, result.real/*.splice(0, fft_size >> 1)*/);
          }
        break;

      case REAL_INLET_2:
        fft_real2.shift();
        fft_real2.push(0);
        fft_real2[(fft_size * 0.5) - 1] = n;      
        break;
      
      default: break;
    }
}

/*-------------------------------------------*/
function correlate()
{
  //STFT.prototype.transform = function(realIn, imagIn, numInSamples, inverse, polarOutput)

  var fft1 = stft1.transform(fft_real1, fft_imag1, fft_size, false, true);
  var fft2 = stft2.transform(fft_real2, fft_imag2, fft_size, false, true);

  var i, temp;
  for(i=0; i<fft_size; i++)
    {
	  /* fft2 is magnitude and phase, not really real and imag */
	  //fft1.real[i] *= fft2.real[i];
	  //fft1.imag[i] *= fft2.real[i];

	  fft1.real[i] *= fft2.real[i];
	  fft1.imag[i] += (Math.TWO_PI - fft2.imag[i]); //complex conjugate

      //convert back to rectangular
      temp = fft1.real[i] * Math.cos(fft1.imag[i]);
      fft1.imag[i] = fft1.real[i] * Math.sin(fft1.imag[i]);
      fft1.real[i] = temp;
    }

  fft1 = inverse_stft.transform(fft1.real, fft1.imag, fft_size, true, true);
  for(i=0; i<(fft_size * 0.5); i++)
    fft1.real.push(fft1.real.shift());
  
  return fft1;
}

/*-------------------------------------------*/
function correlate2()
{
  var result = {real: [], imag: []};;
  var i, j, index;
  var n = 2 * fft_size - 1;
 
  for(i=0; i<n; i++)
    {
	  result.real[i] = 0;
      for(j=0; j<fft_size-1; j++)
        {
	      //easier than finding bounds on this loop...
	      index = fft_size - i - 1 + j;
	      if((index > 0)&&(index < fft_size))
            result.real[i] += fft_real1[fft_size - i - 1 + j] * fft_real2[j];
        }
      result.real[i]*=0.03; //remove later;
    }
  return result;
}