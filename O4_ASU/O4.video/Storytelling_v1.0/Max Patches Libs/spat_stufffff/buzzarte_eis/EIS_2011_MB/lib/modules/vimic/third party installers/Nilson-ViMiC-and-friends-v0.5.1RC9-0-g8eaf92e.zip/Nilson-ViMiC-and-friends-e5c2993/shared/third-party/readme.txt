npej.function, is ej.function, part of great ejies toolbox by Emmanuel Jourdan. http://www.e--j.com/
I am using ej.function for the directivity editor. To allow instant working with ViMiC, I added ej.function and renamed it to npej.function.


