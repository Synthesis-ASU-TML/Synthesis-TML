package colorblobs;
/*******************************
 * PattrGraber.java
 * (c) 2005 by Charlie DeTar
 *
 * Released under the Gnu Public License (GPL).
 * You are free to copy, distribute and modify this software
 * under the terms of the GPL.  There is no warranty whatsoever.
 *
 * PattrGrabbr is a MaxObject to obtain all the preset data from
 * a pattrstorage object, and store it for useful access from other
 * java classes (such as Interpolator).
 */ 
import com.cycling74.max.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

public class PattrGrabbr extends MaxObject
{

    private PattrMap data;
    private boolean grabbing = false;
    private Atom[] previousValues;
    private List expected;
	private HashSet badClients;
    private HashSet ignoredClients;
    private HashMap valueLengths;
    private Timer timer;
    private static final int TIMEOUT = 1000;
    
    private static final String[] INLET_ASSIST = new String[]{
        "From pattrstorage"
    };
    private static final String[] OUTLET_ASSIST = new String[]{
        "Data", "To pattrstorage"
    };
    
    public PattrGrabbr(Atom[] args)
    {
        declareInlets(new int[]{DataTypes.ALL});
        declareOutlets(new int[]{DataTypes.ALL, DataTypes.ALL});
        
        setInletAssist(INLET_ASSIST);
        setOutletAssist(OUTLET_ASSIST);

        expected = new LinkedList();
		badClients = new HashSet();
        valueLengths = new HashMap();
        ignoredClients = new HashSet();
    }
    ///////////////////////////////////////////
    //  Data grabbing
    //
    protected void getSlots(Atom[] slotlist) {
        data = new PattrMap();
        if (slotlist.length > 0) {
            for (int i = 0; i < slotlist.length; i++) {
                int slot = slotlist[i].getInt();
                if (slot != 0) {
                    data.addSlot( slot );
                }
            }
            sendPattr(new Atom[] { Atom.newAtom("getclientlist") });
        }
    }
    /**
     * This method has somewhat complicated data flow, since
     * pattrstorage cannot be relied upon to return a value
     * for each client.  
     *
     * We store each unfulfilled request in the "expected"
     * array.  When we receive a value for any client or
     * when we finish with all the slots of any client, we
     * purge the expected array by a call to addClientValues(values).
     *
     * This has the effect of filling slots that lack a value
     * for a particular client with the "nearest" (above) value in
     * another slot.
     **/
    protected void getClientValues() {
        Iterator clients = data.getClientList().iterator();
        while (clients.hasNext()) {
            String client = (String) clients.next();
            if (!ignoredClients.contains(client)) {
                Iterator slots = data.keySet().iterator();

                previousValues = null;

                while (slots.hasNext()) {
                    Integer slotObj = (Integer) slots.next();
                    int slot = slotObj.intValue();
                    data.setCurrentSlot(slot);
                    
                    expected.add(new Expectation(slot, client));

                    sendPattr(
                        new Atom[] 
                        {   Atom.newAtom("getstoredvalue"),
                            Atom.newAtom(client),
                            Atom.newAtom(slot)
                        }
                    );

                }
                addClientValues( previousValues );
            }
        }

		Iterator remiter = badClients.iterator();
		while (remiter.hasNext()) {
			data.getClientList().remove( (String) remiter.next() );
		}
		badClients.clear();

        listViews();

        MaxSystem.post("done.");
        grabbing = false;
    }
    protected void addClientValues( Atom[] values ) {
        while (expected.size() > 0) {
            Expectation expect = (Expectation) expected.remove(0);
			if (values == null) {
				badClients.add( expect.client );
			} else {
                // determine the length of the values array we received,
                // and whether it conforms to past lengths.
                Integer lengthobj = (Integer) valueLengths.get(expect.client);
                Atom[] newvalues;
                if (lengthobj == null) {
                    // set the values array the first time.
                    valueLengths.put(expect.client, new Integer(values.length));    
                    newvalues = values;
                } else {
                    int desiredLength = lengthobj.intValue();
                    // Trim the values array; past values arrays for
                    // this client were shorter.
                    if (values.length > desiredLength) {
                        newvalues = new Atom[desiredLength];
                        for (int i = 0; i < newvalues.length; i++) {
                            newvalues[i] = values[i];
                        }
                    // grow the values array; past values arrays for
                    // this client were longer.
                    } else if (values.length < desiredLength) {
                        Atom padding = Atom.newAtom(0);
                        newvalues = new Atom[desiredLength];
                        int i = 0;
                        for (i = 0; i < values.length; i++) {
                            newvalues[i] = values[i];
                        }
                        for ( ; i < newvalues.length; i++) {
                            newvalues[i] = padding;
                        }
                    // no change, our values array is well behaved.
                    } else {
                        newvalues = values;
                    }
                } 
                data.storeValue( expect.slot, expect.client, newvalues );
			}
        }
    }

    ///////////////////////////////////////////
    // input/output
    //
    public void anything(String message, Atom[] args) {
        if (grabbing) {
            if (message.equals("slotlist")) {
                getSlots( args ); 
            } else if (message.equals("clientlist")) {
                String client = args[0].getString();
                if (client.equals("done")) {
                    getClientValues();
                } else {
                    data.addClient( client );
                }
            } else {
				previousValues = args;
                // If we are grabbing and don't recognize the message,
                // this means surely we are receiving a client value.
                addClientValues( args );
            }
        } else if (message.equals("read") || message.equals("grab")) {
            grab();
		} else if (message.equals("listView")) {
			listView( args[0].getInt() );
		} else if (message.equals("ignore")) {
            ignore( args[0].getString() );
        } else if (message.equals("unignore")) {
            unignore( args[0].getString() );
        } else if (message.equals("clearIgnored")) {
            clearIgnored();
        }
    }
    public void interpret(double[] args) {
	    interpretDoubles( args );
    }
    public void ignore(String name) {
        ignoredClients.add(name);
    }
    public void unignore(String name) {
        ignoredClients.remove(name);
    }
    public void clearIgnored() {
        ignoredClients.clear();
    }
    
    private void grab() {
        grabbing = true;
        MaxSystem.post("grabbing pattrstorage...");
        sendPattr( new Atom[] { Atom.newAtom("getslotlist") } );
        timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                if (grabbing) {
                    MaxSystem.post("Grab timed out.  No external pattr data.");
                    grabbing = false;
                } 
            }
        }, TIMEOUT);
    }

    private void listView( int slot ) {
        sendInfo(data.listView(slot));  
    }
	public void listViews() {
        Atom[][] lists = data.listViews();
        for (int i = 0; i < lists.length; i++) {
            sendInfo(lists[i]);
        }
        sendInfo(new Atom[] { Atom.newAtom("done") });
	}

    private void interpretDoubles(double[] list) {
        if (data != null) {
            List messages = data.listViewToPattr( list );
            Iterator messiter = messages.iterator();
            while (messiter.hasNext()) {
                sendPattr((Atom[]) messiter.next() );
            }
        }
    }

    public void query(int slot, String client) {
        sendInfo(data.getStoredValue(slot, client));
    }

	protected void sendInfo(Atom[] message) {
		outlet(0, message);
	}

    protected void sendPattr(Atom[] message) {
        outlet(1, message);
    }

    protected void notifyDeleted() {
        if (timer != null) {
            timer.cancel();
        }
    }

    ///////////////////////////////////////////
    // Helper classes
    //
    private class Expectation {
        public String client;
        public int slot;
        public Expectation(int slot, String client) {
            this.client = client;
            this.slot = slot;
        }
    }

    private class PattrMap extends LinkedHashMap {
        private ArrayList clientlist = new ArrayList();
        private int currentSlot = 0;
        
        ////////////////
        // Convenience
        // 
        public void addClient(String name) {
            clientlist.add(name);
        }

        public void addSlot(int i) {
            put(new Integer(i), new LinkedHashMap());
        }

        public LinkedHashMap getSlot(int i) {
            return (LinkedHashMap) get(new Integer(i));
        }

        public Atom[] getStoredValue(int slot, String client) {
            return (Atom[]) ((LinkedHashMap) get(new Integer(slot))).get(client);
        }

        public void storeValue(int slot, String client, Atom[] value) {
            ((LinkedHashMap) get(new Integer(slot))).put(client, value);
        }

        ////////////////
        // settr / gettr
        // 
        public ArrayList getClientList() {
            return clientlist;
        }
        public int getCurrentSlot() {
            return currentSlot;
        }
        public void setCurrentSlot(int val) {
            currentSlot = val;
        }
        public LinkedHashMap getPrototype() {            
            // oh, how I long for a "getFirst" method...
			return (LinkedHashMap) ((Map.Entry) entrySet().iterator().next()).getValue();
        }
        /////////////////
        // Intrpretation
        //
        public Atom[] listView(int slot) {
            LinkedHashMap clients = (LinkedHashMap) get(new Integer(slot)); 
            Iterator clientiter = clients.entrySet().iterator();
            ArrayList atoms = new ArrayList();
			
            // Step through each client...
            while (clientiter.hasNext()) {
                Map.Entry entry = (Map.Entry) clientiter.next();
                String client = (String) entry.getKey();
                Atom[] vals = (Atom[]) entry.getValue();
                // Add every value that is numeric to one big list
                for (int i = 0; i < vals.length; i++) {
                    if (isNumeric(vals[i])) {
                        atoms.add( vals[i] );
                    }
                }
            }
            
            // convrt ArrayList to Atom[]
            Atom[] ret = new Atom[atoms.size()];
            Iterator atomiter = atoms.iterator();
            int i = 0;
            while (atomiter.hasNext()) {
				Atom atom = (Atom) atomiter.next();
                ret[i] = atom;
				i++;
            }
            return ret;
        }

		public Atom[][] listViews() {
			Iterator slotiter = keySet().iterator();
			Atom[][] lists = new Atom[size()][];
			int i = 0;
			while (slotiter.hasNext()) {
				int slot = ((Integer) slotiter.next()).intValue();
				Atom[] list = listView(slot);
				lists[i] = list;
				i++;
			}
			return lists; 
		}

        public boolean isNumeric(Atom a) {
            return a.isInt() || a.isFloat();
        }

        public List listViewToPattr(double[] list) {
            LinkedHashMap clients = getPrototype();
            Iterator clientiter = clients.keySet().iterator();
            ArrayList messages = new ArrayList(clients.size());

            int listPointer = 0;
            int messagesPointer = 0;
            while (clientiter.hasNext()) {
                String client = (String) clientiter.next();
                Atom[] vals = (Atom[]) clients.get( client );

                Atom[] message = new Atom[ vals.length + 1 ];
                message[0] = Atom.newAtom(client);
                // if the value in the prototype is numeric, use the next
                // list value.  Otherwise, use the prototype value. 
				boolean hasNumericValue = false;
                for (int i = 0; i < vals.length; i++) {
                    if ( isNumeric( vals[i] ) ) {
                        message[i + 1] = Atom.newAtom(list[ listPointer ]);
                        listPointer++;
						hasNumericValue = true;
                    } else {
                        message[i + 1] = vals[i];
                    }
                }
				if (hasNumericValue) {
                	messages.add( message );
				}
            }
            return messages;
        }
    }
}










