package colorblobs;
/*******************************
 * Interpolator.java
 * (c) 2005 by Charlie DeTar
 *
 * Released under the Gnu Public License (GPL).
 * You are free to copy, distribute and modify this software
 * under the terms of the GPL.  There is no warranty whatsoever.
 *
 * Interpolator is a MaxObject to interpolate between any number
 * of pattrstorage presets using a list of weights which it receives
 * in the left inlet.
 */ 
import com.cycling74.max.*;

import java.util.ArrayList;
import java.util.Iterator;


public class Interpolator extends MaxObject
{
    private PattrGrabbr pattr;
    private ArrayList lists;
    private int listlength = 0;
    private int rows = 128;
    private int cols = 128;

    //    private boolean precalculate = true;

    public Interpolator(Atom[] args) {
        if (args != null && args.length > 0 && args[0].isInt()) {
            cols = args[0].getInt();
            if (args.length > 1 && args[1].isInt()) {
                rows = args[1].getInt();
            }
        }
        declareAttribute("rows");
        declareAttribute("cols");

        declareInlets(new int[] { DataTypes.ALL, DataTypes.ALL });
        declareOutlets(new int[] { DataTypes.ALL, DataTypes.ALL });

        setInletAssist( new String[] { "Control Messages", "From pattrstorage" } );
        setOutletAssist( new String[] { "Dump output", "To pattrstorage" } );

        pattr = new HijackedPattrGrabbr(this);
        lists = new ArrayList();
        
    }

    ////////////////////////
    // Get pattr info
    //
    public void grab() {
        lists = new ArrayList();
        pattr.anything("grab", new Atom[] {});
    }
    protected void pattrInfo(Atom[] message) {
        if (message[0].isString() && message[0].toString().equals("done")) {
            return;
        } 
        listlength = message.length;

        double[] data = new double[message.length];
        for (int i = 0; i < message.length; i++) {
            data[i] = message[i].toDouble();
        }

        lists.add( data );
    }

    ////////////////////////
    // Calculate
    //
    
    public void interpolate(double[] weights) {
        if (lists.size() > 0) {
            Iterator listiter = lists.iterator();
            int c = 0;
            double[] result = new double[listlength];
            while (listiter.hasNext() && c < weights.length) {
                double[] list = (double[]) listiter.next();
                for (int i = 0; i < list.length; i++) {
                    result[i] += list[i] * weights[c];
                }
                c++;
            }
            pattr.interpret( result );
        }
    }
    
    //////////////////////////////////////////
    //  inlets / outlets
    //
    protected void infoOut(Atom[] message) {
        outlet(0, message);
    }
    protected void pattrOut(Atom[] message) {
        outlet(1, message);
    }
    protected void anything(String message, Atom[] args) {
        if (getInlet() == 1) {
            fromPattr(message, args);
        }
    }
    public void fromPattr(String message, Atom[] args) {
        pattr.anything(message, args);
    }
    
    ////////////////////////////////
    //  Utilities
    //

    private class HijackedPattrGrabbr extends PattrGrabbr {
        private Interpolator encloser;
        public HijackedPattrGrabbr(Interpolator encloser) {
            super(new Atom[] {});
            this.encloser = encloser;
        }    
        protected void sendInfo(Atom[] message) {
            encloser.pattrInfo(message);   
        }
        protected void sendPattr(Atom[] message) {
            encloser.pattrOut(message);
        }
    }
}
        
        



