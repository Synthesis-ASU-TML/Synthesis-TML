package colorblobs;
/*******************************
 * ColorSpaceDriver.java
 * (c) 2005 by Charlie DeTar
 *
 * Released under the Gnu Public License (GPL).
 * You are free to copy, distribute and modify this software
 * under the terms of the GPL.  There is no warranty whatsoever.
 *
 * ColorSpaceDriver is a MaxObject to interface with an LCD 
 * object to make a color space user interface which calculates
 * gaussian weights between colored kernels.  
 */ 
import com.cycling74.max.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashSet;
import java.util.LinkedHashMap;

import LCD.LCDController;

public class ColorSpaceDriver extends LCDController
{
    private static final int CURSOR_SIZE = 18;
	private static double IMAGE_SCALER = 4;
    private static final String SELF_PATTR_NAME = "blobspace";

    private static int PATTR_OUT;
    private static int PATTR_IN;

	// Modes
	private static final int EDIT_MODE = 0;
	private static final int SWIM_MODE = 1;    

	// Edit Mode Actions
	private static final int SWIMMING = 0;
	private static final int RESIZING_X = 1;
	private static final int RESIZING_Y = 2;
	private static final int RESIZING_XY = 4;
	private static final int MOVING = 5;
	private static final int CREATING_TOOP = 6;
    private static final int PICKING_COLOR = 7;

    
	// Asyncrhony
	private int mode = SWIM_MODE;
	private int action = SWIMMING;
    private boolean ignorePreset = false;
	private ArrayList toops;	
	private Toop activeToop = null;
    private Toop colorChoice = null;
    private Toop[] colorPickers = null;

    private SpaceInterpolator interpolator;

    // Presets
    private DoubleList preset = new DoubleList();
    private static final int NUM_PRESET_ELEMENTS = 9;

	// Attributes
    private boolean interpolate = true;
	private boolean idlemouse = false;
	private boolean inverty = false;
    private double[] zoom = new double[] {1, 0, 0}; // scale, centerx, centery
    // Fine drawing calibration
    // NOTE:  these are "opt-in" draw commands, trumped
    // by the global "draw" boolean from super
    private boolean drawclear = false;
    private boolean drawblobs = false;
    private boolean drawnumbers = false;
    private boolean drawcursor = false;
    private boolean draweditor = false;
    private boolean drawcolorpicker = false;
	
    private boolean allowselfreference;

    // Optimization
    private HashSet visitedColors;
    private boolean allColorsVisited;
    
	public ColorSpaceDriver(Atom[] args)
	{
        super(args);
        PATTR_OUT = outlets.size();
        PATTR_IN = inlets.size();
        inlets.put("from external pattrstorage", new Integer(DataTypes.ALL));
        outlets.put("to external pattrstorage", new Integer(DataTypes.ALL));
        
		declareAttribute("idlemouse");
		declareAttribute("interpolate");
		declareAttribute("inverty");		
        declareAttribute("zoom", "getzoom", "setzoom");
        declareAttribute("drawclear");
        declareAttribute("drawblobs");
        declareAttribute("drawnumbers");
        declareAttribute("drawcursor");
        declareAttribute("draweditor");
        declareAttribute("drawcolorpicker");

        declareAttribute("allowselfreference", "getallowselfreference", "setallowselfreference");

		toops = new ArrayList();
        interpolator = new SpaceInterpolator(this);

        construct();
	}
	protected void loadbang() {
        super.loadbang();
        allColorsVisited = false;
        visitedColors = new HashSet(Toop.NUM_COLORS);
        setallowselfreference(false);
	}
    public void init() {
        super.init();
        visitedColors.clear();
        for (int i = 0; i < Toop.NUM_COLORS; i++) {
            loadImage(i, true);
        }
    } 
    private void loadImage(int n) {
        loadImage(n % Toop.NUM_COLORS, !allColorsVisited && !visitedColors.contains(new Integer(n)));
    }
    private void loadImage(int n, boolean f) {
        if (f) {
            Atom gaussian = Atom.newAtom("gaussian"+n+".png");
            sendLCD(new Atom[] { Atom.newAtom("readpict"), gaussian, gaussian });
            visitedColors.add(new Integer(n));
            if (visitedColors.size() == Toop.NUM_COLORS) {
               allColorsVisited = true; 
            }
        }
    }
        

    private void setzoom(double[] args) {
        if (args.length == 1 && args[0] > 0) {
            zoom = new double[] { args[0], activeMouse[0], activeMouse[1] };
        } else if (args.length == 3 && args[0] > 0) {
            zoom = new double[3];
            zoom[0] = args[0];
            double[] center = javaToLcd(args[1], args[2]);
            zoom[1] = center[0];
            zoom[2] = center[1];
        } 

        Iterator toopiter = toops.iterator();
        while (toopiter.hasNext()) {
            Toop toop = (Toop) toopiter.next();

            toop.offset( lcdToJava( zoom[1], zoom[2] ) );
            toop.scale(zoom[0]);
            updatePreset(toop);
        }
        redraw();
    }
    private double[] getzoom() {
        return zoom;
    }
    /*
     * We need to ignore the pattrstorage that drives our space preset object.  
     * Otherwise, storing an external preset after the internal preset has
     * a value results in the external preset controlling the internal preset
     * number.  
     *
     * This is different from self reference in the form of the example patch,
     * where the external pattrstorage in greedy mode actually sees the space
     * arrangement preset object.  Here we just want to exclude the pattrstorage.
     */
    private void setallowselfreference(boolean ref) {
        if (ref) {
            sendInterpolator("clearIgnored", null);
        } else {
            MaxPatcher parent = getParentPatcher();
            sendInterpolator("ignore", new Atom[] {
                    Atom.newAtom( getParentPatcher().getName() + "::" + SELF_PATTR_NAME )
            });
        }
        allowselfreference = ref;
    }
    private boolean getallowselfreference() {
        return allowselfreference;
    }
        

	////////////////////////////////////
	//     Drawing methods
	//

	public void clearLCD() {
        if (!draw && !drawclear) {
            return;
        }

        sendLCD("brgb", new double[] {0,0,0});
        sendLCD("clear");
	}

	public void redraw() {
		clearLCD();

        // fail fast
        if (!draw && !drawblobs && !drawnumbers) {
            return;
        }
        arrows = null;

		Iterator toopiter = toops.iterator();
		while (toopiter.hasNext()) {
			drawToop((Toop) toopiter.next());
		}

        drawCursor(activeMouse);
	}

    public void drawCursor(double[] pos) {
        if (!draw && !drawcursor) {
            return;
        }
        Atom[] pensize = new Atom[] { Atom.newAtom("pensize"), Atom.newAtom(4), Atom.newAtom(1) };
        Atom gray = Atom.newAtom(128);
        Atom[] cursor = new Atom[] { 
            Atom.newAtom("frameoval"),
            Atom.newAtom( pos[0] - CURSOR_SIZE / 2),
            Atom.newAtom( pos[1] - CURSOR_SIZE / 2),
            Atom.newAtom( pos[0] + CURSOR_SIZE / 2),
            Atom.newAtom( pos[1] + CURSOR_SIZE / 2),
            gray, gray, gray
        };

        penmode(PENMODE_XOR);
        sendLCD(pensize);
        sendLCD(cursor);
    }

	private void drawToop(Toop toop) {
        if (draw || drawblobs) {
            // Set penmode
            penmode(PENMODE_ADDMAX);

            // Calculate position
            double width = toop.xstd() * IMAGE_SCALER;
            double height = toop.ystd() * IMAGE_SCALER;
            double topLeftX = toop.x() - width/2;
            double topLeftY = toop.y() - height/2;

            double[] offset = javaToLcd(topLeftX, topLeftY);
            double[] breadth = javaToLcd(width, height);
            // Draw toop
            Atom[] tooper = new Atom[] {
                Atom.newAtom("drawpict"),
                Atom.newAtom("gaussian"+toop.color()+".png"),
                Atom.newAtom(offset[0]),
                Atom.newAtom(offset[1]),
                Atom.newAtom(breadth[0]),
                Atom.newAtom(breadth[1])
            };
            sendLCD(tooper);
        }
        if (draw || drawnumbers) {
            // Draw numerical label
            Atom white = Atom.newAtom(200);
            Atom[] frgb = new Atom[] { Atom.newAtom("frgb"), white, white, white };
            double[] center = javaToLcd(toop.x(), toop.y());
            Atom[] move = new Atom[] {
                Atom.newAtom("moveto"),
                Atom.newAtom(center[0] - 5), // Fudge for proper positioning of font
                Atom.newAtom(center[1] + 5)
            };
            Atom[] write = new Atom[] {
                Atom.newAtom("write"),
                Atom.newAtom(toop.index() + 1)
            };
            penmode(PENMODE_XOR);
            sendLCD(frgb);
            sendLCD(move);
            sendLCD(write);
        }
	}

	private void drawActiveRing(Toop toop) {
        if (!draw && !draweditor) {
            return;
        }
		if (toop != null) {

			double[] center = javaToLcd( toop.x(), toop.y() );
			double[] breadth = javaToLcd( toop.xstd(), toop.ystd() );

			
			Atom white = Atom.newAtom(255);
			Atom leftX = Atom.newAtom(center[0] - breadth[0]);
			Atom leftY = Atom.newAtom(center[1] - breadth[1]);
			Atom rightX = Atom.newAtom(center[0] + breadth[0]);
			Atom rightY = Atom.newAtom(center[1] + breadth[1]);

            Atom[] pensize = new Atom[] { Atom.newAtom("pensize"), Atom.newAtom(1), Atom.newAtom(1) };

			Atom[] ring = new Atom[] { 
				Atom.newAtom("frameoval"), leftX, leftY, rightX, rightY, white, white, white
			};

			Atom[] square = new Atom[] {
				Atom.newAtom("framerect"), leftX, leftY, rightX, rightY, white, white, white
			};

            penmode(PENMODE_XOR);
            sendLCD(pensize);
			sendLCD(ring);
			sendLCD(square);
		}
	}
    private void drawArrows(int potAct) {
        if (!draw && !draweditor) {
            return;
        }
        eraseArrows();
        int type = -1;
        if (potAct == RESIZING_X) {
            type = Arrow.X;
        } else if (potAct == RESIZING_Y) {
            type = Arrow.Y;
        } else if (potAct == MOVING) {
            type = Arrow.XY;
        } else if (potAct == RESIZING_XY) {
            double[] center = lcdToJava(idleMouse[0], idleMouse[1]);
            if ( (activeToop.x() - center[0]) * (activeToop.y() - center[1]) < 0) {
                type = Arrow.NESW;
            } else {
                type = Arrow.NWSE;
            }
        }
        if (type != -1) {
            super.drawArrows( prevIdleMouse, type );
        }
	}

    private void drawColorPicker() {
        if (!draw && !drawcolorpicker) {
            return;
        }
        if (!allColorsVisited) {
            for (int i = 0; i < Toop.NUM_COLORS; i++) {
                loadImage(i);
            }
        }
        penmode(PENMODE_COPY);

        int colorows = 4;
        double perrow = Math.ceil((double)Toop.NUM_COLORS / colorows);

        double xspacing = cols / Toop.NUM_COLORS * 2;
        double yspacing = rows / Toop.NUM_COLORS * 2;

        double boxleft = cols * 0.5 - xspacing * Math.ceil(perrow / 2);
        double boxright = cols * 0.5 + xspacing * Math.ceil(perrow / 2);
        double boxtop = rows * 0.5 - xspacing * Math.ceil(colorows / 2);
        double boxbottom = rows * 0.5 + xspacing * Math.ceil(colorows / 2);

        Atom[] box = new Atom[] {
            Atom.newAtom("paintrect"),
            Atom.newAtom(boxleft),
            Atom.newAtom(boxtop),
            Atom.newAtom(boxright),
            Atom.newAtom(boxbottom),
            Atom.newAtom(0), Atom.newAtom(0), Atom.newAtom(0)
        };
        sendLCD(box);

        int gci = Toop.GLOBAL_COLOR_INDEX;
        colorPickers = new Toop[Toop.NUM_COLORS];
        int colorow = 0;
        for (int i = 0; i < Toop.NUM_COLORS; i++) {
            if (i % perrow == 0) {
                colorow += 1;
            }
            double[] center = lcdToJava( xspacing * (i % perrow + 1) + boxleft, boxtop + yspacing * colorow ); 
            double[] width = lcdToJava( xspacing, yspacing );
            colorPickers[i] = new Toop(center[0], center[1], width[0], width[1], i, i);
            drawToop(colorPickers[i]);
        }
        Toop.GLOBAL_COLOR_INDEX = gci;
    }
    private void drawAndEraseRing(Toop previous, Toop current) {
        if (
                (current != null && !current.equals(previous)) ||
                (previous != null && current == null))
        {
            drawActiveRing(current);
            drawActiveRing(previous);
        }
    }

	////////////////////////////////////
	//     Interpretation
	//
    
	private void getAndDrawActiveToop() {
		Toop prevActiveToop = activeToop;
		Toop closest = null;
		double distance = Double.MAX_VALUE;
		double[] point = lcdToJava( idleMouse[0], idleMouse[1] );

		Iterator toopiter = toops.iterator();
		while (toopiter.hasNext()) {
			Toop toop = (Toop) toopiter.next();
			if (toop.contains( point[0], point[1] )) {
				double d = toop.distance(point[0], point[1]);
				if (d < distance) {
					distance = d;
					closest = toop;
				}
			}
		}
        activeToop = closest;
        drawAndEraseRing(prevActiveToop, activeToop);
	}
    private void getAndDrawColorChoice() {
        Toop prevColorChoice = colorChoice;
        Toop closest = null;
        double[] point = lcdToJava( idleMouse[0], idleMouse[1] );
        for (int i = 0; i < colorPickers.length; i++) {
            if (colorPickers[i].contains( point[0], point[1] )) {
                closest = colorPickers[i];
            }
        }
        colorChoice = closest;
        drawAndEraseRing(prevColorChoice, colorChoice);
    }

	private double[] getWeights(double x, double y) {
        try {
            double[] weights = new double[toops.size()];
            Iterator toopiter = toops.iterator();
            double total = 0;
            int c = 0;
            while (toopiter.hasNext()) {
                Toop toop = (Toop) toopiter.next();
                weights[c] = toop.weight(x, y);
                total += weights[c];
                c++;
            }
            double[] normalizedWeights = new double[weights.length];

            for (int i = 0; i < weights.length; i++) {
                normalizedWeights[i] = weights[i] / total;
            }
            return normalizedWeights;	
        } catch (NullPointerException e) {
            return new double[] {};
        }
	}

	private int getPotentialAction() {
		int potentialAction = SWIMMING;
		if (activeToop != null) {

			double[] center = javaToLcd( activeToop.x(), activeToop.y() );
			double[] offset = new double[] { center[0] - idleMouse[0], center[1] - idleMouse[1] };

			double[] stds = javaToLcd( activeToop.xstd(), activeToop.ystd() );

			double xproportion = Math.abs(offset[0]) / (double) stds[0];
			double yproportion = Math.abs(offset[1]) / (double) stds[1];

			if ( xproportion > 0.7 && yproportion < 0.2 ) {
				potentialAction = RESIZING_X;
			} else if (xproportion < 0.2 && yproportion > 0.7) {
				potentialAction = RESIZING_Y;
            } else if (xproportion > 0.7 && yproportion > 0.7) {
                potentialAction = RESIZING_XY;
			} else {	
				potentialAction = MOVING;
			}
		}
		return potentialAction;
	}

	////////////////////////////////////
	//     Inputs from LCD
	//

    public void mouseDown(int value) {
        if (value == 1) {
            if (action == CREATING_TOOP) {
                double[] center = lcdToJava(idleMouse[0], idleMouse[1]);
                double[] toopArray = new double[] { 
                    center[0], center[1], 20, 20
                };
                add(toopArray);
            } else if (action == PICKING_COLOR) {
                if (colorChoice != null) {
                    activeToop.color(colorChoice.color());
                    action = SWIMMING;
                    colorChoice = null;
                    redraw();
                }
            } else {
                action = getPotentialAction();
            }
        }
    }
    public void modifiers(int value) {
        if (value == SHIFT) {
            mode = EDIT_MODE;
            getAndDrawActiveToop();
        } else if (value == COMMAND) {
            action = CREATING_TOOP;
        } else {
            mode = SWIM_MODE;
            action = SWIMMING;
            activeToop = null;
            colorChoice = null;
            redraw();
        }
    }
    public void keyboard(int value) {
        if (mode == EDIT_MODE && value == DELETE_KEY) {
            if (activeToop != null) {
                delete( activeToop.index() + 1);
                activeToop = null;
            }
        } else if (mode == EDIT_MODE && value == ENTER_KEY) {
            if (activeToop != null && action != PICKING_COLOR) {
                eraseArrows();
                drawColorPicker();
                action = PICKING_COLOR;
            }
        }
	}

    public void control(String message, Atom[] args) {
        if (message.equals("list")) {
            double x = args[0].isInt() ? args[0].getInt() : args[0].isFloat() ? args[0].getFloat() : 0;
            double y = args[1].isInt() ? args[1].getInt() : args[1].isFloat() ? args[1].getFloat() : 0;
            double newy = inverty ? 128 - y : y;
			double[] grid = javaToLcd(x, newy);

            sendCursorPos( grid[0], grid[1] );
			sendWeights( grid[0], grid[1]); 
            updateActiveMouse( grid[0], grid[1] );
            updateCursor( (int) Math.round(grid[0]), (int) Math.round(grid[1]) );
		} else {
		// Ignore that which we do not understand, for it is inconvenient to us
        }
    }

    public void idleMouse(double x, double y) {
        if (action == PICKING_COLOR) {
            getAndDrawColorChoice();

        } else if (mode == EDIT_MODE) {
            drawArrows(getPotentialAction());
            getAndDrawActiveToop();

        } else if (idlemouse) {
            sendCursorPos(x, y);
            sendWeights(x, y);
            updateActiveMouse(x, y);
            updateCursor(x, y);
        }
    }
    public void activeMouse(double x, double y) {
        if (mode == EDIT_MODE && activeToop != null) {

            double[] center = javaToLcd( activeToop.x(), activeToop.y() );
            double[] distFromCenter = new double[] { center[0] - x, center[1] - y };				

            if (action == RESIZING_X || action == RESIZING_Y || action == RESIZING_XY) {
                if (action != RESIZING_X) {
                    activeToop.ystd( Math.abs(lcdToJava(distFromCenter[0], distFromCenter[1])[1]) );
                }
                if (action != RESIZING_Y) {
                    activeToop.xstd( Math.abs(lcdToJava(distFromCenter[0], distFromCenter[1])[0]) );
                }
            } else {
                double[] offset = new double[] { center[0] - idleMouse[0], center[1] - idleMouse[1] };
                double[] toopDest = lcdToJava( x + offset[0], y + offset[1] ); 
                activeToop.moveto( toopDest[0], toopDest[1] );
                idleMouse[0] = x;
                idleMouse[1] = y;
            }
            updatePreset(activeToop);

            redraw();
            updateIdleMouse(x, y);
            drawArrows(action);
            drawActiveRing(activeToop);
        } 
        
        updateCursor(x, y);
        sendCursorPos(x, y);
        sendWeights(x, y);
	}

    public void updateCursor(double x, double y) {
        if (mode == SWIM_MODE) {
            drawCursor(prevActiveMouse);
            drawCursor(activeMouse);
            zoom[1] = x;
            zoom[2] = y;
        }
    }

	/////////////////////////////
	// Presets
 	//
    public void clearPreset() {
        super.clearPreset();
        preset.clear();
    }
	private void appendPreset(Toop toop) {
        if (toop != null) {
            preset.add( toop.x() );
            preset.add( toop.y() );
            preset.add( toop.xstd() );
            preset.add( toop.ystd() );
            preset.add( toop.color() );
            preset.add( toop.index() );
            preset.add( toop.scale() );
            preset.add( toop.offset()[0] );
            preset.add( toop.offset()[1] );
            sendPreset();
        }
	}
    private void updatePreset(Toop toop) {
        if (toop != null) {
            int start = toop.index() * NUM_PRESET_ELEMENTS;
            preset.set( start + 0, toop.x() );
            preset.set( start + 1, toop.y() );
            preset.set( start + 2, toop.xstd() );
            preset.set( start + 3, toop.ystd() );
            preset.set( start + 4, toop.color() );
            preset.set( start + 5, toop.index() );
            preset.set( start + 6, toop.scale() );
            preset.set( start + 7, toop.offset()[0] );
            preset.set( start + 8, toop.offset()[1] );
            sendPreset();
        }
    }
    protected void loadPreset(Atom[] args) {
        if (ignorePreset || args.length <= 1) {
            return;
        }
        boolean drawstate = draw;
        // don't draw until all presets are loaded...
        draw = false;

        toops.clear();
        preset.clear();
        preset.addAll(args);

        double x,y,xstd,ystd;
        int color,index;
        double scale,offsetx,offsety;
        // satisfy the compiler...
        x = y = xstd = ystd = scale = offsetx = offsety = 0.;
        color = index = 0;
        for (int i = 0; i < args.length; i++) {
            double d = args[i].toDouble();
            switch (i % NUM_PRESET_ELEMENTS) {
                case 0: x = d; break;
                case 1: y = d; break;
                case 2: xstd = d; break;
                case 3: ystd = d; break;
                case 4: color = (int) (d + 0.5); break;
                case 5: index = (int) (d + 0.5); break;
                case 6: scale = d; break;
                case 7: offsetx = d; break;
                case 8: 
                    offsety = d; 
                    loadToop(x,y,xstd,ystd,color,index,scale,offsetx,offsety);
                break;
            }
        }
        draw = drawstate;
        redraw();
    }
    // Add a toop, updating images and drawing, but not updating presets.
    private Toop loadToop(double x, double y, double xstd, double ystd, int color, int index, double scale, double offsetx, double offsety) {
        Toop toop = new Toop(x,y,xstd,ystd,color,index,scale,offsetx,offsety);
		toops.add(toop);

        loadImage(color);
		redraw();
        return toop;
    }

	/////////////////////////////
	// Outputs
 	//
    private void sendPreset() {
        ignorePreset = true;
        outlet(PRESET_OUT, preset.toArray());
        ignorePreset = false;
    }
    private void sendCursorPos(double gridx, double gridy) {
        double[] xy = lcdToJava(gridx, gridy);
        sendWorld("cursor", new Atom[] { Atom.newAtom(xy[0]), Atom.newAtom(xy[1]) });
    }
	private void sendWeights(double col, double row) {
        if (!interpolate || toops.isEmpty()) {
            return;
        }
		double[] pos = lcdToJava(col, row);
        double[] weights = getWeights(pos[0], pos[1]);
        if (weights.length > 0) {
            sendWorld("weights", weights);	
        }
        interpolator.interpolate(weights);
	}
    private void sendInterpolator(String message, Atom[] args) {
        interpolator.anything(message, args);
    }

	///////////////////////////////.
	//      Control Messages (input CONTROL_IN)
	//

    public void anything(String message, Atom[] args) {
        super.anything(message, args);
        if (getInlet() == PATTR_IN) {
            interpolator.fromPattr(message, args);
        }
    }
    
    public void grab() {
        interpolator.grab();
    }

	public void clear() {
		toops.clear();
        clearPreset();
		redraw();
	}
	public void set(Atom[] args) {
		if (args[0].isString() && args[0].getString().equals("clear")) {
			toops.clear();
            zoom = new double[] { 1, 0, 0 };
		}
	}
	public void add(double[] args) {
        double offsety = args.length > 8 ? args[8] : zoom[2];
        double offsetx = args.length > 7 ? args[7] : zoom[1];
        double scale = args.length > 6 ? args[6] : zoom[0];
        int index = args.length > 5 ? (int)args[5] : toops.size();
        int color = args.length > 4 ? (int)args[4] : Toop.nextColor();

		Toop toop = loadToop(args[0], args[1], args[2], args[3], color, index, scale, offsetx, offsety);
        appendPreset(toop);
	}
	public void delete(int index) {
        index -= 1;
        if (index >= 0 && index < toops.size()) {
            clearPreset();
            ArrayList newToops = new ArrayList();
            for (int i = 0,c=0; i < toops.size(); i++) {
                Toop toop = (Toop) toops.get(i);
                if (toop.index() != index) {
                    toop.index(c);
                    newToops.add(toop);
                    appendPreset(toop);
                    c++;
                }
            }
            toops = newToops;
        }
        redraw();
	}
    public void getblobinfo(int toopNum) {
        if (toopNum > toops.size() || toopNum < 1) {
            MaxSystem.post("error: colorblobs: No blob "+toopNum+" exists.");
            return;
        }
        Toop toop = (Toop) toops.get(toopNum - 1);
        Atom[] info = new Atom[] { 
            Atom.newAtom(toopNum),
            Atom.newAtom(toop.x()),
            Atom.newAtom(toop.y()),
            Atom.newAtom(toop.xstd()),
            Atom.newAtom(toop.ystd()),
            Atom.newAtom(toop.color())
        };
        sendWorld("blobinfo", info);
    }
    public void getbloblist() {
        Atom[] list = new Atom[ toops.size() ];
        for (int i = 0; i < list.length; i++) {
            list[i] = Atom.newAtom(i + 1);
        }
        sendWorld("bloblist", list);
    }
    public void setblobsize(double[] args) {
        if (args.length != 3) {
            MaxSystem.post("error: colorblobs: setblobsize requires 3 args - blob index, xsize, ysize");
            return;
        }
        int index = (int) args[0] - 1;
        if (index > toops.size() || index < 0) {
            return;
        }
        
        Toop toop = (Toop) toops.get(index);
        toop.xstd(args[1]);
        toop.ystd(args[2]);
        redraw();
        updatePreset(toop);
    }
    public void setblobpos(double[] args) {
        if (args.length != 3) {
            MaxSystem.post("error: colorblobs: setblobpos requires 3 args - blob index, xpos, ypos");
            return;
        }
        int index = (int) args[0] - 1;
        if (index > toops.size() || index < 0) {
            return;
        }
        Toop toop = (Toop) toops.get(index);
        toop.x(args[1]);
        toop.y(args[2]);
        redraw();
        updatePreset(toop);
    } 
    public void setblobcolor(int[] args) {
        if (args.length != 2) {
            MaxSystem.post("error: colorblobs: setblobcolor requires 2 args - blob index, color index");
            return;
        }
        int index = (int) args[0] - 1;
        if (index > toops.size() || index < 0) {
            return;
        }
        Toop toop = (Toop) toops.get(index);
        toop.color(args[1]);
        loadImage(args[1]);
        redraw();
        updatePreset(toop);
    }

    private class SpaceInterpolator extends Interpolator {
        MaxObject encloser;
        
        public SpaceInterpolator(MaxObject encloser) {
            super(new Atom[] {});
            this.encloser = encloser;
        }
        protected void pattrOut(Atom[] message) {
            encloser.outlet(PATTR_OUT, message);
        }
        protected void infoOut(Atom[] message) {}
    }

    public class DoubleList {
        public double[] data = new double[40];
        private int top = 0;
        public void add(double d) {
            if (top >= data.length) {
                resize((int) (data.length * 1.5));
            }
            data[top] = d;
            top++;
        }
        private void resize(int newsize) {
            double[] newdata = new double[newsize];
            int upperLimit = Math.min(data.length, newsize);
            for (int i = 0; i < upperLimit; i++) {
                newdata[i] = data[i];
            }
            data = newdata;
        }
            
        public int size() {
            return top;
        }
        public void set(int i, double d) {
            if (i > top) {
                throw new ArrayIndexOutOfBoundsException(i);
            }
            data[i] = d;
        }
        public double[] toArray() {
            double[] out = new double[top];
            for (int i = 0; i < top; i++) {
                out[i] = data[i];
            }
            return out;
        }
        public void clear() {
            top = 0;
        }
        public void addAll(Atom[] d) {
            if (top + d.length > data.length) {
                resize((int) (top + d.length * 1.5));
            }
            for (int i = 0; i < d.length; i++) {
                add(d[i].toDouble());
            }
        }
        public void addAll(double[] d) {
            if (top + d.length > data.length) {
                resize((int) (top + d.length * 1.5));
            }
            for (int i = 0; i < d.length; i++) {
                add(d[i]);
            }
        }
    }
}
