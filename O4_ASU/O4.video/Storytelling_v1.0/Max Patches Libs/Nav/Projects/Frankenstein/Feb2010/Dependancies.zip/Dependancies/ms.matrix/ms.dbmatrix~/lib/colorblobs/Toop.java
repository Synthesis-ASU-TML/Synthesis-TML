package colorblobs;
public class Toop {
    public static int RESOLUTION = 128;
    public static int NUM_COLORS = 19;
    public static int GLOBAL_COLOR_INDEX = NUM_COLORS - 1;
    private static final int MIN_STDEV = 3;
    private double x;
    private double y;
    private double xstd;
    private double ystd;
    private int color;
    private int index;

    private double scale = 1;
    private double[] offset = new double[] {0, 0};

    public Toop(double x, double y, double xstd, double ystd, int color, int index, double scale, double offsetx, double offsety) {
        this.scale = scale; 
        this.offset[0] = offsetx; 
        this.offset[1] = offsety;
        x(x); 
        y(y);
        xstd(xstd); 
        ystd(ystd);
        color(color); 
        this.index = index; 
    }
    public Toop(double x, double y, double xstd, double ystd, int color, int index) {
        this(x, y, xstd, ystd, color, index, 1, 0, 0);
    }
    public Toop(double x, double y, double xstd, double ystd, int index) {
        this(x, y, xstd, ystd, GLOBAL_COLOR_INDEX, index);
    }   
    public double weight(double xp, double yp) {
        // bivariate gaussian distribution!!!
        return Math.exp(-(xp-x())*(xp-x())/(2*xstd()*xstd()) - (yp-y())*(yp-y())/(2*ystd()*ystd()));
    }
    public boolean contains(double xp, double yp) {
        int stdevs = 1;
        return Math.abs(x() - xp) < xstd() * stdevs && 
            Math.abs(y() - yp) < ystd() * stdevs;
    }
    public void move(double dx, double dy) {
        x = x + dx;
        y = y + dx;
    }
    public void moveto(double x, double y) {
        x(x);
        y(y);
    }
    public double distance(double xp, double yp) {
        return  Math.sqrt( (xp-x())*(xp-x()) + (yp-y())*(yp-y()) );
    }
    public static int nextColor() {
        return (GLOBAL_COLOR_INDEX + 1) % NUM_COLORS;
    }

    public double x() {
        return x * scale + adjOff(offset[0]);
    }
    public double y() {
        return y * scale + adjOff(offset[1]);
    }
    public double xstd() {
        return xstd * scale;
    }
    public double ystd() {
        return ystd * scale;
    }
    public int color() {
        return color;
    }
    public int index() {
        return index;
    }
    public double scale() {
        return scale;
    }
    public double[] offset() {
        return offset;
    }
    public void x(double x) {
        this.x = (x - adjOff(offset[0])) / scale;
    }
    public void y(double y) {
        this.y = (y - adjOff(offset[1])) / scale;
    }
    public void xstd(double xstd) {
        this.xstd = Math.max(xstd, MIN_STDEV) / scale;
    }
    public void ystd(double ystd) {
        this.ystd = Math.max(ystd, MIN_STDEV) / scale;
    }
    public void index(int index) {
        this.index = index;
    }
    public void color(int color) {
        this.color = color % NUM_COLORS;
        GLOBAL_COLOR_INDEX = color;
    }
    public String toString() {
        return "[index: "+index+"; color: "+color+"; position: "+x+" "+y+"; stdev: "+xstd+" "+ystd+"]";
    }
    public void scale(double scale) {
        if (scale > 0) {
            this.scale = scale;
        }
    }
    public void offset(double[] newoff) {
        x += (adjOff(offset[0]) - adjOff(newoff[0])) / scale;
        y += (adjOff(offset[1]) - adjOff(newoff[1])) / scale;
        offset = newoff;
    }

    public double adjOff( double amt ) {
        return (1 - scale) * amt;
    }
}   

