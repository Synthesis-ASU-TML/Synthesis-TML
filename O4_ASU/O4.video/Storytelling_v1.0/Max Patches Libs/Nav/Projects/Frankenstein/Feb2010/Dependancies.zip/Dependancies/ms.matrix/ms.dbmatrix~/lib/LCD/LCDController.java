package LCD;

import com.cycling74.max.*;
import java.util.LinkedHashMap;
import java.util.Iterator;
import java.util.Map;

public class LCDController extends MaxObject {
    // INLETS
    protected static final int CONTROL_IN = 0;
    protected static final int ACTIVE_MOUSE_IN = 1;
    protected static final int IDLE_MOUSE_IN = 2;
    protected static final int MOUSE_DOWN_IN = 3;
    protected static final int LCD_DUMP_IN = 4;
    protected static final int MODIFIERS_IN = 5;
    protected static final int KEYBOARD_IN = 6;
    protected static final int PRESET_IN = 7;
    // OUTLETS
    protected static final int WORLD_OUT = 0;
    protected static final int LCD_OUT = 1;
    protected static final int PRESET_OUT = 2;

    // Keys
    protected static final int DELETE_KEY = 8;
    protected static final int ENTER_KEY = 13;
    protected static final int SPACE_KEY = 32;

    protected static final int SHIFT = 1;
    protected static final int CAPS_LOCK = 2;
    protected static final int ALT = 4;
    protected static final int CONTROL = 8;
    protected static final int COMMAND = 16;
    
    // Utilities
    protected static final int PENMODE_COPY = 0;
    protected static final int PENMODE_OR = 1;
    protected static final int PENMODE_XOR = 2;
    protected static final int PENMODE_BIC = 3;
    protected static final int PENMODE_NOTCOPY = 4;
    protected static final int PENMODE_NOTOR = 5;
    protected static final int PENMODE_NOTXOR = 6;
    protected static final int PENMODE_NOTBIC = 7;
    protected static final int PENMODE_BLEND = 32;
    protected static final int PENMODE_ADDPIN = 33;
	protected static final int PENMODE_ADDOVER = 34;
	protected static final int PENMODE_SUBPIN = 35;
	protected static final int PENMODE_TRANSPARENT = 36;
    protected static final int PENMODE_ADDMAX = 37;
	protected static final int PENMODE_SUBOVER = 38;
	protected static final int PENMODE_ADDMIN = 39;
    

    // asynchrony
    protected double[] idleMouse = new double[] {0,0};
    protected double[] prevIdleMouse = new double[] {0,0};
    protected double[] activeMouse = new double[] {0,0};
    protected double[] prevActiveMouse = new double[] {0,0};
    protected Arrow arrows = null;
    protected int rows = 128;
    protected int cols = 128;

    protected boolean shiftdown = false;
    protected boolean controldown = false;
    protected boolean commanddown = false;
    protected boolean capsdown = false;
    protected boolean altdown = false;

    // instance
    protected double xscale = 128.;
    protected double yscale = 128.;
    public boolean draw = true;
    
    protected LinkedHashMap inlets = new LinkedHashMap();
    protected LinkedHashMap outlets = new LinkedHashMap();
    
    /*********************
     * Constructors / init
     */
    
    public LCDController(Atom[] args) {
        
        declareAttribute("draw", "getDraw", "setDraw");

        inlets.put("control", new Integer(DataTypes.ALL));
        inlets.put("active mouse x y", new Integer(DataTypes.LIST));
        inlets.put("idle mouse x y", new Integer(DataTypes.LIST));
        inlets.put("mouse down 1/0", new Integer(DataTypes.INT));
        inlets.put("LCD dump in", new Integer(DataTypes.ALL));
        inlets.put("Modifiers in", new Integer(DataTypes.INT));
        inlets.put("keyboard in", new Integer(DataTypes.INT));
        inlets.put("preset in", new Integer(DataTypes.INT));
        
        outlets.put("dump output", new Integer(DataTypes.ALL));
        outlets.put("LCD control", new Integer(DataTypes.ALL));
        outlets.put("preset out", new Integer(DataTypes.ALL));

    }
    protected void construct() {
        // c style array fillers
        String[] strs = new String[inlets.size()];
        int[] ints = new int[inlets.size()];

        parseLets(strs, ints, inlets);
        declareInlets(ints);
        setInletAssist(strs);

        strs = new String[outlets.size()];
        ints = new int[outlets.size()];
        
        parseLets(strs, ints, outlets);
        declareOutlets(ints);
        setOutletAssist(strs);
    }

    protected void loadbang() {
        sendLCD("getsize");
        sendLCD("idle", new double[] { 1 });
        sendLCD("local", new double[] { 0 });
    }
    public void init() {
        loadbang();
    }
    
    private void parseLets(String[] strs, int[] ints, LinkedHashMap lets) {
        Iterator types = lets.entrySet().iterator();
        for (int i = 0; types.hasNext(); i++) {
            Map.Entry next = (Map.Entry) types.next();
            strs[i] = (String) next.getKey();
            ints[i] = ((Integer) next.getValue()).intValue();
        }
    }

    public void bang() {
        redraw();
    }

    public boolean getDraw() {                                                        
        return draw;                                                                   
    }                                                                                  
    public void setDraw(boolean d) {                                               
        this.draw = d;
        if (draw) {                                                                    
            redraw();                                                                    
        }                                                                              
    }                                                                                  


    /****************
     * outs
     */
    
    public void sendWorld(String message, Atom[] args) {
        outlet(WORLD_OUT, message, args);
    }
    public void sendWorld(String message, double[] args) {
        outlet(WORLD_OUT, message, args);
    }
    public void sendWorld(Atom[] args) {
        outlet(WORLD_OUT, args);
    }
    public void sendWorld(String message) {
        outlet(LCD_OUT, message);
    }
    //------- send lcd massively overloaded --//
    public void sendLCD(String message, Atom[] args) {
        outlet(LCD_OUT, message, args);
    }
    public void sendLCD(Atom[] args) {
        outlet(LCD_OUT, args);
    }
    public void sendLCD(String message) {
        outlet(LCD_OUT, message);
    }
    public void sendLCD(String message, double[] args) {
        outlet(LCD_OUT, message, args);
    }
    public void sendLCD(String message, double args) {
        outlet(LCD_OUT, message, args);
    }
    public void sendLCD(String message, int args) {
        outlet(LCD_OUT, message, args);
    }
    public void sendLCD(String message, int[] args) {
        outlet(LCD_OUT, message, args);
    }
    //------- 
    public void clearPreset() {
        outlet(PRESET_OUT, 0);
    }
    public void sendPreset(Atom[] message) {
        outlet(PRESET_OUT, message);
    }
   /***************
    * ins
    */
    public void size(int[] args) {
        cols = args[0];
        rows = args[1];
        redraw();
    }
    public void anything(String message, Atom[] args) {
        if (getInlet() == CONTROL_IN) {
            control(message, args);
            return;
        }
    }
    public void inlet(int n) {
        if (getInlet() == MOUSE_DOWN_IN) {
            mouseDown(n);
        } else if (getInlet() == MODIFIERS_IN) {
            shiftdown = n == SHIFT;
            controldown = n == CONTROL;
            commanddown = n == COMMAND;
            capsdown = n == CAPS_LOCK;
            altdown = n == ALT;

            modifiers(n);
        } else if (getInlet() == KEYBOARD_IN) {
            keyboard(n);
        } else {
            control(n);
        }
    }
    public void inlet(double d) {
        control(d);
    }
    public void list(Atom[] list) {
        if (getInlet() == IDLE_MOUSE_IN || getInlet() == ACTIVE_MOUSE_IN) {
            double x = list[0].isInt() ? list[0].getInt() : list[0].isFloat() ? list[0].getFloat() : 0;
            double y = list[1].isInt() ? list[1].getInt() : list[1].isFloat() ? list[1].getFloat() : 0;
            
            if (getInlet() == IDLE_MOUSE_IN) {
                updateIdleMouse(x, y);
                idleMouse(x, y);
            } else if (getInlet() == ACTIVE_MOUSE_IN) {
                updateActiveMouse(x, y);
                activeMouse(x, y);
            }
        } else if (getInlet() == PRESET_IN) {
            loadPreset(list);
        } else {
            control("list", list);
        }
    }
    public void updateIdleMouse(double x, double y) {
        prevIdleMouse[0] = idleMouse[0];
        prevIdleMouse[1] = idleMouse[1];
        idleMouse[0] = x;
        idleMouse[1] = y;
    }
    public void updateActiveMouse(double x, double y) {
        prevActiveMouse[0] = activeMouse[0];
        prevActiveMouse[1] = activeMouse[1];
        activeMouse[0] = x;
        activeMouse[1] = y;
    }


    /***********************
     * Abstract event handlers
     */
    protected void control(String message, Atom[] args) {};
    protected void control(int n) {};
    protected void control(double n) {};
    protected void loadPreset(Atom[] args) {};
    public void idleMouse(double x, double y) {};
    public void activeMouse(double x, double y) {};
    public void mouseDown(int m) {};
    public void modifiers(int m) {};
    public void keyboard(int k) {};

    /**********************
     * Drawing...
     */
    public void redraw() {};
    public void clearLCD() {
        sendLCD("clear");
    }
    public void penmode(int n) {
        sendLCD("penmode", new double[] { n });
    }
        
    protected void eraseArrows() {
        if (!draw) {
            return;
        }
        try {
            arrows.draw();
            arrows = null;
        } catch (NullPointerException e) {}
    }       
    protected void drawArrows(double[] location, int type) {
        if (!draw) {
            return;
        }
        arrows = new Arrow(location, type);
        arrows.draw();
    }
    
    /*********************
     * Scaling...
     */
    public double[] javaToLcd(double col, double row) {
        return new double[] {
            col / xscale * cols,
            row / yscale * rows
        };
    }
    public double[] lcdToJava(double x, double y) {
        return new double[] {
            x / cols * xscale,
            y / rows * yscale
        };
    }

    /*********************
     * Arrows...
     */
    // "constant interface antipattern"
    protected class Arrow extends ArrowData {
        public double[] center = new double[] {0, 0};
        public int type;

        public Arrow(double[] center, int type) {
            this.center[0] = center[0];
            this.center[1] = center[1];
            this.type = type;
        }
        public void draw() {
            if (!draw) {
                return;
            }
            if (type == XY) {
                drawArrows(polys[X]);
                drawArrows(polys[Y]);
            } else if (type == NWSENESW) {
                drawArrows(polys[NESW]);
                drawArrows(polys[NWSE]);
            } else {
                drawArrows(polys[type]);
            }
        }
        private void drawArrows(int[] poly) {
            penmode(PENMODE_XOR);
            Atom[] arrow = new Atom[ poly.length ];
            for (int i = 0; i < poly.length; i++) {                          
                arrow[i] = Atom.newAtom( poly[i]*2 + center[ i%2 ] );          
            };                                                               
            sendLCD("paintpoly", arrow);                                     
        }                                                                    
    }                                                                        
    private static class ArrowData {
        public static final int X = 0;
        public static final int Y = 1;
        public static final int NWSE = 2;
        public static final int NESW = 3;
        public static final int XY = 5;
        public static final int NWSENESW = 6;
        public static final int[][] polys = new int[][] {
            /* X */ new int[] {
                5,0, 5,-5, 10,0, //top of right head 
                5,5, 5,0,  //bottom of right head 
                -5,0, -5,-5, -10,0, //top of left head 
                -5,5, -5,1, 5,1 //bottom of left head
            },
            /* Y */ new int[] {
                0,-5, -5,-5, 0,-10, //left of top head
                5,-5, 0,-5, //right of top head                                           
                0,5, -5,5, 0,10, // left of bottom head
                5,5, 1,5, 1,-5 // right of bottom head 
            },
            /* NWSE */ new int[] {
                -4,-3, -6,0, -6,-6, 
                0,-6, -3,-4,
                4,2, 6,0, 6,6, 
                0,6, 3,4, -4,-3
            },
            /* NESW */ new int[] {
                -4,3, -6,0, -6,6, 
                0,6, -3,4,
                4,-2, 6,0, 6,-6, 
                0,-6, 3,-4, -4,3
            }
        };
        public static int[] get(int i) {
            return polys[i];
        }
    }
}
