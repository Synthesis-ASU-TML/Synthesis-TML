How to set up the Max/MSP/Jitter environment for TML after original installation

- copy "TML externals 080103" to "externals" folder!
- copy "TML helps 080103" to "max-help" folder!

yoichiro
08.01.03
